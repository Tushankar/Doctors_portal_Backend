// server.js
import express from "express";
import dotenv from "dotenv";
import cors from "cors";
import cookieParser from "cookie-parser";
import connectDB from "./config/db.js";
import { errorHandler, notFound } from "./middleware/errorMiddleware.js";

// Route imports
import authRoutes from "./routes/authRoutes.js";
import adminRoutes from "./routes/adminRoutes.js";
import prescriptionRoutes from "./routes/prescriptionRoutes.js";
import patientRoutes from "./routes/patientRoutes.js";
import pharmacyRoutes from "./routes/pharmacyRoutes.js";
import inventoryRoutes from "./routes/inventoryRoutes.js";
import chatRoutes from "./routes/chatRoutes.js";
import orderRoutes from "./routes/orderRoutes.js";
import advancedNotificationRoutes from "./routes/advancedNotificationRoutes.js";
import contactRoutes from "./routes/contactRoutes.js";
import refillRoutes from "./routes/refillRoutes.js";

// Load env vars
dotenv.config();

// Connect to database
connectDB();

const app = express();

// Body parser
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Cookie parser
app.use(cookieParser());

// Enable CORS
app.use(
  cors({
    origin: function (origin, callback) {
      if (process.env.NODE_ENV === "production") {
        callback(null, process.env.FRONTEND_URL === origin);
      } else {
        // Allow localhost on any port for development
        if (!origin || /^http:\/\/localhost:\d+$/.test(origin)) {
          callback(null, true);
        } else {
          callback(new Error("Not allowed by CORS"));
        }
      }
    },
    credentials: true,
  })
);

// Routes
app.use("/api/v1/auth", authRoutes);
app.use("/api/v1/admin", adminRoutes);
// Prescription routes
app.use("/api/v1/prescriptions", prescriptionRoutes);
// Pharmacy routes
app.use("/api/v1/pharmacies", pharmacyRoutes);
// Inventory routes for CSV upload and product management
app.use("/api/v1/pharmacies", inventoryRoutes);
// Chat routes for patient-pharmacy messaging
app.use("/api/v1/chat", chatRoutes);
// Order routes for order management
app.use("/api/v1/orders", orderRoutes);
// Advanced notification routes (unified notification system)
app.use("/api/v1/notifications", advancedNotificationRoutes);
// Patient routes
app.use("/api/v1/patients", patientRoutes);
// Contact routes for contact form and info
app.use("/api/v1/contact", contactRoutes);
// Refill routes for prescription refill requests
app.use("/api/v1/refills", refillRoutes);

// Test route
app.get("/", (req, res) => {
  res.send("API is running...");
});

// Error middleware
app.use(notFound);
app.use(errorHandler);

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log(`Server running in ${process.env.NODE_ENV} mode on port ${PORT}`);
});
